package com.example.group5_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
