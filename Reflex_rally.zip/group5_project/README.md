# group5_project

The user interactive game -  Reflex Rally! 

We are creating a game where the user gets to interact with their phone in fun ways, 
in the spirit of “Bop It”. 
The game utilizes the sensors in our phones to give the user a satisfying and entertaining experience. 
The game will tell you to tap your screen, swipe different directions, 
shake your phone and much more. We will utilize a combo-system to reward players for consistency and speed. 
timers will make you more prone to errors, background music and sound effects will give you an entertaining experience. 
You can share your score with friends and try to beat each other's highscore.

Let's play Reflex Rally!

by: Sharokin Issa, Martin Lindblad, Simon Alén, Tom Jonsson
